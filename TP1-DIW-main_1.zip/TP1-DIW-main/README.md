# TP1-DIW — Spider Movies

Site com todos os filmes do Homem-Aranha (Tom Holland, Andrew Garfield e Tobey Maguire).
Feito só com **HTML, CSS, JavaScript, Bootstrap 5 e json-server**.

## Como rodar

```bash
npm install
npm start
```

Abra **http://localhost:3000** no navegador.

O `npm start` sobe o json-server, que entrega a API (`/filmes`, `/atores`) e também
os arquivos do site. Não abra o `index.html` com duplo clique (`file://`): o YouTube
bloqueia trailers fora de um servidor e o `fetch` não alcança a API.

## Funcionalidades

- Cards montados a partir do `db.json` (via `fetch` no json-server)
- Zoom no pôster ao passar o mouse + botão de play
- Trailer abre em um modal (quadro 16:9) e para de tocar ao fechar
- Sinopse em cada card
- Página de detalhes (`Filme.html?id=...`) com pôster, ficha, trailer e sinopse

## Estrutura

```
db.json        dados dos filmes e atores
index.html     página inicial
Filme.html     página de detalhes
style.css      estilos das duas páginas
js/api.js      URL da API e funções comuns
js/home.js     monta os cards e o modal do trailer
js/filme.js    monta a página de detalhes
```

Para adicionar um filme, inclua um objeto em `filmes` no `db.json`, com o `youtubeId`
(o código depois de `watch?v=` na URL do YouTube).
