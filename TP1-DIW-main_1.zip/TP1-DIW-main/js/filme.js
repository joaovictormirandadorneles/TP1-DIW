const detalhe = document.querySelector("#detalhe");

function telaFilme(filme, ator) {
    return `
    <div class="fundo-filme" style="background-image:url('${filme.capa}')" aria-hidden="true"></div>
    <div class="row g-4 g-lg-5 align-items-start">
        <div class="col-md-4 col-lg-3">
            <div class="poster-detalhe borda-${filme.cor}">
                <img src="${filme.capa}" alt="Pôster de ${escapar(filme.titulo)}">
            </div>
        </div>
        <div class="col-md-8 col-lg-9">
            <span class="badge text-bg-danger mb-2">${filme.ano}</span>
            <h1 class="titulo-filme">${escapar(filme.titulo)}</h1>
            <p class="titulo-br fs-5">${escapar(filme.tituloBr)}</p>
            <ul class="list-inline info-filme">
                <li class="list-inline-item"><strong>Peter Parker:</strong> ${escapar(ator?.nome ?? "-")}</li>
                <li class="list-inline-item"><strong>Direção:</strong> ${escapar(filme.diretor ?? "-")}</li>
            </ul>

            <h2 class="h4 mt-4 mb-3">Trailer</h2>
            <div class="player ratio ratio-16x9 borda-${filme.cor}" id="player">
                <button type="button" class="player-capa" id="btnPlay"
                    aria-label="Assistir trailer de ${escapar(filme.titulo)}">
                    <img src="${miniaturaTrailer(filme)}" alt="">
                    <span class="poster-play grande" aria-hidden="true">
                        <svg viewBox="0 0 24 24" width="46" height="46"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>
                    </span>
                </button>
            </div>

            <h2 class="h4 mt-4 mb-2">Sinopse</h2>
            <p class="sinopse-detalhe">${escapar(filme.sinopse)}</p>

            <a href="index.html#${filme.ator}" class="btn btn-outline-light mt-3">← Voltar para os filmes</a>
        </div>
    </div>`;
}

async function iniciar() {
    const id = new URLSearchParams(window.location.search).get("id");

    try {
        const filmes = await buscar(`filmes?id=${encodeURIComponent(id)}`);
        const filme = filmes[0];

        if (!filme) {
            detalhe.innerHTML = `
                <div class="text-center my-5">
                    <h1>Filme não encontrado</h1>
                    <p>Verifique o endereço e tente novamente.</p>
                    <a href="index.html" class="btn btn-aranha">Voltar ao início</a>
                </div>`;
            return;
        }

        const atores = await buscar(`atores?id=${encodeURIComponent(filme.ator)}`);
        document.title = `${filme.titulo} | Spider Movies`;
        detalhe.innerHTML = telaFilme(filme, atores[0]);

        // Clicou no play: troca a miniatura pelo vídeo do YouTube
        document.querySelector("#btnPlay").addEventListener("click", () => {
            document.querySelector("#player").innerHTML = `
                <iframe src="${urlTrailer(filme)}" title="Trailer de ${escapar(filme.titulo)}"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`;
        });
    } catch (erro) {
        console.error(erro);
        detalhe.innerHTML = mensagemErroServidor();
    }
}

iniciar();
