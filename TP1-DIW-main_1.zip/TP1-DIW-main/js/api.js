// Endereço do json-server (rode: npm start)
const API_URL = "http://localhost:3000";

async function buscar(caminho) {
    const resposta = await fetch(`${API_URL}/${caminho}`);
    if (!resposta.ok) {
        throw new Error(`Erro ${resposta.status} ao buscar ${caminho}`);
    }
    return resposta.json();
}

// Monta a URL de "embed" do YouTube (a URL /watch?v= NÃO funciona dentro de iframe)
function urlTrailer(filme) {
    const params = new URLSearchParams({
        autoplay: 1,
        rel: 0,
        modestbranding: 1,
        start: filme.inicio || 0
    });
    return `https://www.youtube.com/embed/${filme.youtubeId}?${params}`;
}

function miniaturaTrailer(filme) {
    return `https://img.youtube.com/vi/${filme.youtubeId}/hqdefault.jpg`;
}

// Evita injeção de HTML ao montar o conteúdo com template strings
function escapar(texto) {
    const div = document.createElement("div");
    div.textContent = texto ?? "";
    return div.innerHTML;
}

function mensagemErroServidor() {
    return `
        <div class="alert alert-danger text-center my-5" role="alert">
            <h2 class="h5 mb-2">Não foi possível carregar os filmes</h2>
            <p class="mb-0">Verifique se o json-server está rodando em <code>${API_URL}</code>
            (no terminal, dentro da pasta do projeto: <code>npm start</code>).</p>
        </div>`;
}
