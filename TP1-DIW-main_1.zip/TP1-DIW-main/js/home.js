const conteudo = document.querySelector("#conteudo");
const navAtores = document.querySelector("#nav-atores");
const modalEl = document.querySelector("#modalTrailer");
const modalTitulo = document.querySelector("#modalTrailerTitulo");
const modalPlayer = document.querySelector("#modalTrailerPlayer");
const modal = new bootstrap.Modal(modalEl);

let filmesPorId = {};

function cardFilme(filme) {
    return `
    <div class="col">
        <article class="card card-filme h-100 borda-${filme.cor}">
            <button type="button" class="poster" data-trailer="${filme.id}"
                aria-label="Assistir trailer de ${escapar(filme.titulo)}">
                <img src="${filme.capa}" alt="Pôster de ${escapar(filme.titulo)}" loading="lazy">
                <span class="poster-play" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="34" height="34"><path fill="currentColor" d="M8 5v14l11-7z"/></svg>
                </span>
                <span class="poster-ano">${filme.ano}</span>
            </button>
            <div class="card-body d-flex flex-column">
                <h3 class="card-title h6 mb-1">${escapar(filme.titulo)}</h3>
                <p class="titulo-br mb-2">${escapar(filme.tituloBr)}</p>
                <p class="sinopse flex-grow-1">${escapar(filme.sinopse)}</p>
                <div class="d-flex flex-wrap gap-2 mt-2">
                    <button type="button" class="btn btn-aranha btn-sm flex-grow-1" data-trailer="${filme.id}">
                        ▶ Trailer
                    </button>
                    <a class="btn btn-outline-light btn-sm" href="Filme.html?id=${filme.id}">Detalhes</a>
                </div>
            </div>
        </article>
    </div>`;
}

function secaoAtor(ator, filmes) {
    return `
    <section class="secao-ator" id="${ator.id}">
        <h2 class="subtitulo"><span>${escapar(ator.nome)}</span> Spider-Man Movies</h2>
        <div class="row row-cols-2 row-cols-md-3 row-cols-xl-4 g-3 g-md-4">
            ${filmes.map(cardFilme).join("")}
        </div>
    </section>`;
}

function abrirTrailer(id) {
    const filme = filmesPorId[id];
    if (!filme) return;
    modalTitulo.textContent = `${filme.titulo} (${filme.ano})`;
    modalPlayer.innerHTML = `
        <iframe src="${urlTrailer(filme)}" title="Trailer de ${escapar(filme.titulo)}"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`;
    modal.show();
}

// Ao fechar o modal, remove o iframe para o vídeo parar de tocar
modalEl.addEventListener("hidden.bs.modal", () => {
    modalPlayer.innerHTML = "";
});

conteudo.addEventListener("click", (evento) => {
    const botao = evento.target.closest("[data-trailer]");
    if (botao) abrirTrailer(botao.dataset.trailer);
});

async function iniciar() {
    try {
        const [atores, filmes] = await Promise.all([buscar("atores"), buscar("filmes")]);
        filmes.forEach((f) => (filmesPorId[f.id] = f));

        atores.sort((a, b) => a.ordem - b.ordem);

        conteudo.innerHTML = atores
            .map((ator) => {
                const lista = filmes.filter((f) => f.ator === ator.id).sort((a, b) => a.ano - b.ano);
                return lista.length ? secaoAtor(ator, lista) : "";
            })
            .join("");

        navAtores.innerHTML = atores
            .map((a) => `<li class="nav-item"><a class="nav-link" href="#${a.id}">${escapar(a.nome)}</a></li>`)
            .join("");
    } catch (erro) {
        console.error(erro);
        conteudo.innerHTML = mensagemErroServidor();
    }
}

iniciar();
